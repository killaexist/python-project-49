### Hexlet tests and linter status:
[![Actions Status](https://github.com/killaexist/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/killaexist/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/eaa665158cdeb36daff4/maintainability)](https://codeclimate.com/github/killaexist/python-project-49/maintainability)
https://asciinema.org/connect/5e71f27a-68ac-4c2e-961d-71ebca394cf3 - Even Game

https://asciinema.org/a/iPNfvBNY4YJ3EEJcYQMQw4IUp - Calculator Game
