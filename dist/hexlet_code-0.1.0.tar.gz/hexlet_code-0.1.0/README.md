### Hexlet tests and linter status:
[![Actions Status](https://github.com/killaexist/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/killaexist/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/eaa665158cdeb36daff4/maintainability)](https://codeclimate.com/github/killaexist/python-project-49/maintainability)

                          Asciinema Demonstration:

https://asciinema.org/a/fOnc0PpFN3OxZKHURimEkd1D0 - Even Game

https://asciinema.org/a/iPNfvBNY4YJ3EEJcYQMQw4IUp - Calculator Game

https://asciinema.org/a/DXwHKxZcxbxbJ3VwK362GDwNL - Gcd Game

https://asciinema.org/a/4ABndVajlsDc0xsqJyp3nvsKF - Progression Game

https://asciinema.org/a/J9xDQCJg8xCXHEV2JXpDWNG9A - Prime Game
